## SCRIPT FOR CREATING A HEAT MAP BETWEEN TWO DATASETS IN AA DF FORMAT ##

#Loading packages
library(dplyr)
library(stats)
library(ggplot2)
library(svglite)

############################# USER INPUTS ####################################

#User inputs
print("Choose two files to compare (_aa_occurrences.csv format)")
aa_df_list <- basename(choose.files(default = paste0(getwd(), "/Output/Data/*.*"), caption = "Choose two files to compare (_aa_occurrences.csv format)", multi = TRUE))

#Asking user for positions to look at
aa_positions <- readline("Choose positions to include in heatmap (format 1, 2, 3, etc): ");

plot_title_heatmap <- readline("Choose title for plot: ")

##############################################################################

#Split aa_positions and add Pos to each number
aa_positions_split <- strsplit(aa_positions, ", ")
aa_positions_split[[1]] <- sort(as.numeric(aa_positions_split[[1]]), decreasing = FALSE)
aa_positions_split_pos <- paste0("Pos", aa_positions_split[[1]])

#Reading and normalizing files
aa_df_list_data <- lapply(paste0("Output/Data/", aa_df_list, sep = ""), read.csv)
aa_normalized <- dget("Scripts/aa_occurrences_normalized.R")
aa_df_list_data <- lapply(aa_df_list_data, aa_normalized)

#Removing values of non-allowed amino acids
for (i in 1:length(aa_df_list_data)) {
  aa_df_list_data[[i]] <- aa_df_list_data[[i]] %>% mutate_all(function(x) ifelse(x < 0.1, 0, x))
}

#Calculating factor rise between chosen aa occurrence data sets
aa_factor_rise <- aa_df_list_data[[2]][2:length(aa_df_list_data[[2]])]/aa_df_list_data[[1]][2:length(aa_df_list_data[[1]])]
aa_factor_rise <- aa_factor_rise %>% mutate_all(function(x) ifelse(is.infinite(x), 0, x))

#Creating heatmap of per position aa factor rise between the chosen data sets
aa_list <- c("A", "R", "N", "D", "C", "Q", "E", "G", "H", "I", "L", "K", "M", "F", "P", "S", "T", "W", "Y", "V", "*")
rownames(aa_factor_rise) <- aa_list

#Extracting wanted positions from aa_factor_rise df
aa_factor_rise_pos <- aa_factor_rise[,aa_positions_split_pos]
colnames(aa_factor_rise_pos) <- c(aa_positions_split[[1]])

#Melting data frame
aa_factor_rise_long <- cbind(aa_list, aa_factor_rise_pos)
aa_factor_rise_long <- reshape2::melt(aa_factor_rise_long)

#Adjusting width of image
len <- length(aa_factor_rise_pos)
wid <- (len*0.4)

#Plotting heat map
#The breaks can be changed if other intervals are preferred BUT remember to
#change in "labels" in the command of heatmap_p as well, and to choose the
#same number of colors as the number of intervals (also specified in the
#heatmap_p command as "values").
aa_factor_rise_long_new <- aa_factor_rise_long
aa_factor_rise_long_new$groups <- cut(aa_factor_rise_long_new$value,
                                      breaks = c(0.000001, 0.2, 0.5, 1, 2, 5, 10, Inf))

heatmap_p12 <- ggplot(data = subset(aa_factor_rise_long_new, is.na(value)), aes(x = variable, y = aa_list, fill = value)) + geom_tile(aes(colour = "N/A"), linetype = 0, fill = "lightgray") + labs(color = " ")

heatmap_p <- heatmap_p12 + geom_tile(data = aa_factor_rise_long_new, aes(fill = groups), color = "gray") + scale_fill_manual(breaks = rev(levels(aa_factor_rise_long_new$groups)), values = c("#D73027", "#FDAE61", "#FEE08B", "#D9EF8B", "#A6D96A", "#1A9850", "#006837"), labels = c(">10", "5-10", "2-5", "1-2", "0.5-1", "0.2-0.5", "<0.2"), na.value = "lightgray") +
  theme_minimal() + labs(title = paste0("Heat map residue factor increase\n", plot_title_heatmap, sep = ""), fill = "Factor rise") + xlab("Position") + ylab("Amino acid") +
  theme(plot.title = element_text(hjust = 0.5)) + guides(color = guide_legend(reverse = T))

ggsave(paste0("Output/Plots/", gsub("_sorted_aa_occurrences.csv", "", aa_df_list[1]), "_to_", gsub("_sorted_aa_occurrences.csv", "", aa_df_list[2]), "_aa_heatmap.svg", sep = ""), heatmap_p, width=wid, height=7)


