## SCRIPT TO CREATE A HISTOGRAM OF AA OCCURRENCES IN EACH POSITION ##

#Loading packages
library(ggplot2)
library(reshape2)
library(svglite)
library(stringr)

######################### NOW IN AA MOTHER SCRIPT ############################
###################UNCOMMENT IF SCRIPT IS RUN INDIVIDUALLY####################

# #Letting the user choose input file
# print("Choose input file (format _aa_occurrences.R)")
# input_file <- basename(choose.files(default = paste0(getwd(), "/Output/Data/*.*"), caption = "Choose input file (format _aa_occurrences.R)", multi = F))
# input_file_name <- gsub("_aa_occurrences.csv", "", input_file)
# input_file_data <- read.csv(paste0("Output/Data/", input_file, sep = ""))

 #Asking user for positions to look at
# aa_positions <- readline("Choose positions to include in histogram (format 1, 2, 3, etc): ");
#
# plot_title_histogram <- readline("Choose title for plot: ")

##############################################################################

#Loading and running normalization function
#the input file of the function "aa_occurrences_df" is created with script "aa_occurrences.R"
aa_normalized <- dget("Scripts/aa_occurrences_normalized.R")
aa_normalized_df <- aa_normalized(input_file_data)

#Split aa_positions and add Pos to each number
aa_positions_split <- strsplit(aa_positions, ", ")
aa_positions_split[[1]] <- sort(as.numeric(aa_positions_split[[1]]), decreasing = FALSE)
aa_positions_split_pos <- paste0("Pos", aa_positions_split[[1]])

#Creating df with values for histogram
hist_data <- subset(aa_normalized_df, select = -c(Amino_acid))
hist_data <- hist_data[aa_positions_split_pos]
colnames(hist_data) <- c(aa_positions_split[[1]])

#Melting data and creating long df
hist_data_long <- hist_data
hist_data_long$amino_acid <- as.factor(aa_normalized_df$Amino_acid)
hist_data_long <- reshape2::melt(hist_data_long, id.vars = "amino_acid")

#Creating color palette for histogram
list_of_colors <- c(53, 134, 116, 142, 96, 367, 51, 121, 40, 46, 101, 147, 563, 544, 68, 47, 420, 535, 431, 575, 236)
mypalette <- colors()[list_of_colors]

#Adjusting width of image
len <- length(hist_data)
wid <- (len*0.5)

#Plot histogram
aa_per_position_hist <- ggplot(hist_data_long, aes(x = variable, y = value, fill = amino_acid)) + geom_histogram(stat = "identity") +
  geom_text(aes(label = paste0(ifelse(value > 10, paste0(amino_acid, "\n", round(value, 0), "%", sep = ""), ifelse(value > 3, paste0(amino_acid), "")))), position = position_stack(vjust = 0.5), color = "white", size = 3.5, fontface = "bold") +
  theme_minimal() + labs(x = "Position", y = "Occurrence (%)", fill = "Amino acid", title = paste0("Amino acid histogram per position\n", plot_title_histogram, sep = "")) +
  scale_fill_manual(values = mypalette, breaks = hist_data_long$amino_acid) + theme(plot.title = element_text(hjust = 0.5))

ggsave(paste("Output/Plots/", input_file_name, "_aa_per_pos_hist", ".svg", sep = ""), plot = aa_per_position_hist, width=wid, height=6)

