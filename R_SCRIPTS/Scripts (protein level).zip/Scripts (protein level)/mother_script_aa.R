## MOTHER SCRIPT FOR AMINO ACID ANALYSES ON DATASETS ##

#User inputs
print("Choose file(s) for amino acid analysis (_sorted.csv format)")
file_list_input <- basename(choose.files(default = paste0(getwd(), "/Output/Data/*.*"), caption = "Choose file(s) for amino acid analysis (_sorted.csv format)", multi = TRUE))
reading_frame <- as.integer(readline("Choose reading frame (1, 2 or 3): "))
start_pos <- readline("Enter start positon of protein (aa level): ")
aa_positions <- readline("Choose sequence positions to include in amino acid histogram (format 1, 2, 3, etc): ")

start_time <- Sys.time()

#Run aa analyses for the chosen files
for (m in 1:length(file_list_input)) {
  input_file <- file_list_input[m]
  source("Scripts/aa_occurrences.R")
  input_file_data <- aa_occurrences_df
  track_title <- gsub("_", "", str_extract(file_list_input[m], str_extract(file_list_input[m], "(_[A-Z]_)")))
  round_title <- gsub("\\D+|\\_*", "", file_list_input[m])
  plot_title_histogram <- paste0("Round ", round_title, " track ", track_title)
  source("Scripts/aa_histogram.R")
}

end_time <- Sys.time()
