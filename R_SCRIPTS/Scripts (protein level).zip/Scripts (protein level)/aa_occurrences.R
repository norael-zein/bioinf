### SCRIPT FOR COUNTING OCCURENCES OF EACH AMINO ACID IN ALL SEQUENCES OF INPUT FILE ###

######################### NOW IN AA MOTHER SCRIPT ###########################
###################### UNCOMMENT IF RUN INDIVIDUALLY ########################

# #Letting the user choose input file
# print("Choose input file (_sorted.csv format)")
# input_file <- basename(choose.files(default = paste0(getwd(), "/Output/Data/*.*"), caption = "Choose input file (_sorted.csv format)", multi = FALSE))
# reading_frame <- as.numeric(readline("Choose reading frame (1, 2 or 3): "))
# start_pos <- readline("Enter start position of protein (aa level): ")

#############################################################################
#Loading packages (uncomment first two lines if Biostrings is missing)
# library(BiocManager)
# BiocManager::install("Biostrings")

library(svMisc)

#Saving name of input file and reading
input_file_name <- (gsub(".csv", "", input_file))
aa_seq_df <- read.csv(paste0("Output/Data/", input_file, sep = ""))

#Splitting amino acid sequences
aa_split <- strsplit(aa_seq_df$Sequence_aa, "")
aa_seq_df$aa_split <- aa_split

#Creating data frame for occurences of aa:s
aa_list <- c("A", "R", "N", "D", "C", "Q", "E", "G", "H", "I", "L", "K", "M", "F", "P", "S", "T", "W", "Y", "V", "*")
aa_occurrences_df <- data.frame(matrix(0, ncol = max(lengths(aa_seq_df$aa_split))+1, nrow = length(aa_list)))
colnames(aa_occurrences_df) <- c("Amino_acid")
aa_occurrences_df$Amino_acid <- aa_list

#Editing colnames in both data frames
if (start_pos != 1) {
  for (i in 2:(as.numeric(start_pos))) {
    colnames(aa_occurrences_df)[i] <- paste0("Primer_", i-1, sep = "")
  }
}

for (i in (as.numeric(start_pos)+1):(max(lengths(aa_seq_df$aa_split))+1)) {
  colnames(aa_occurrences_df)[i] <- paste0("Pos", i-as.numeric(start_pos), sep = "")
}

#Counting occurrences of each amino acid in each position
pb <- txtProgressBar(min = 0, max = length(aa_seq_df$Sequence_aa), style = 3)
k <- 0
print("Counting AA:s progress: ")
for (i in 1:length(aa_seq_df$Sequence_aa)) {
  for (j in 1:length(aa_seq_df$aa_split[[i]])) {
    aa_intersect <- intersect(aa_seq_df$aa_split[[i]][[j]], aa_occurrences_df$Amino_acid)
    aa_pos <- match(aa_intersect, aa_occurrences_df$Amino_acid)
    num_aa <- length(aa_intersect)*aa_seq_df$n[i]
    aa_occurrences_df[aa_pos,j+1] <- aa_occurrences_df[aa_pos,j+1] + num_aa
  }
  k <- k+1
  setTxtProgressBar(pb, k, title = "Current file progress")
}

write.csv(aa_occurrences_df, file = paste0("Output/Data/", input_file_name, "_aa_occurrences.csv"), row.names = F, quote = F)

#Calculating frameshift
#1st approach
#perc_stop <- (sum(aa_occurrences_df[21, 2:length(aa_occurrences_df)]) / sum(aa_occurrences_df[1:21, 2:length(aa_occurrences_df)]))*100

#2nd approach
#perc_aa_fs <- 0
#for (i in 2:length(aa_occurrences_df)) {
#  sum_aa_fs <- 0
#  for (j in 1:20) {
#    if (aa_occurrences_df[j,i] < 100) {
#      sum_aa_fs <- sum_aa_fs + aa_occurrences_df[j,i]
#    }
#  }
#  perc_aa_fs <- perc_aa_fs + sum_aa_fs
#}
#perc_aa_fs <- (perc_aa_fs / sum(aa_occurrences_df[1:21, 2:length(aa_occurrences_df)]))*100
#print(paste0("Frameshift calculations for ", input_file_name, ":"))
#perc_stats <- tibble("Frameshift based on stop codons (%)" = perc_stop, "Frameshift based on threshold (%)" = perc_aa_fs)

#print(perc_stats)
print("Calculation is done")
