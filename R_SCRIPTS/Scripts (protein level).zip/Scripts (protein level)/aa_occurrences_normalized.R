## FUNCTION FOR NORMALIZING AA OCCURRENCES RAW NUMBERS ##

#Input data frame is a data frame of aa occurrences
aa_occurrences_normalized <- function(input_df) {
  aa_tot <- sum(input_df$Pos1)
  aa_normalized_df <- (input_df[1:length(input_df$Amino_acid), 2:length(input_df[1,])]/aa_tot)*100
  aa_normalized_df <- cbind(Amino_acid = input_df$Amino_acid, aa_normalized_df)
  return(aa_normalized_df)
}

#test_df <- aa_occurrences_normalized(aa_occurrences_df)